#!/bin/bash
i686-w64-mingw32-gcc -o swtor_fix.exe swtor_fix.c -Wall -Wextra && cp swtor_fix.exe ~/.wine/drive_c/

